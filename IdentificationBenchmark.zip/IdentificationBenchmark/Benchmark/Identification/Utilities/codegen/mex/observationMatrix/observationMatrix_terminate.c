/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * observationMatrix_terminate.c
 *
 * Code generation for function 'observationMatrix_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "observationMatrix.h"
#include "observationMatrix_terminate.h"
#include "_coder_observationMatrix_mex.h"
#include "observationMatrix_data.h"

/* Function Definitions */
void observationMatrix_atexit(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  mexFunctionCreateRootTLS();
  st.tls = emlrtRootTLSGlobal;
  emlrtEnterRtStackR2012b(&st);
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

void observationMatrix_terminate(void)
{
  emlrtStack st = { NULL,              /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  st.tls = emlrtRootTLSGlobal;
  emlrtLeaveRtStackR2012b(&st);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

/* End of code generation (observationMatrix_terminate.c) */
