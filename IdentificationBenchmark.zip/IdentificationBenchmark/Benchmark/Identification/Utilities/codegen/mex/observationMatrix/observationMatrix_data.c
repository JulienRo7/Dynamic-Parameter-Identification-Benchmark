/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * observationMatrix_data.c
 *
 * Code generation for function 'observationMatrix_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "observationMatrix.h"
#include "observationMatrix_data.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
const volatile char_T *emlrtBreakCheckR2012bFlagVar = NULL;
emlrtContext emlrtContextGlobal = { true,/* bFirstTime */
  false,                               /* bInitialized */
  131466U,                             /* fVersionInfo */
  NULL,                                /* fErrorFunction */
  "observationMatrix",                 /* fFunctionName */
  NULL,                                /* fRTCallStack */
  false,                               /* bDebugMode */
  { 2045744189U, 2170104910U, 2743257031U, 4284093946U },/* fSigWrd */
  NULL                                 /* fSigMem */
};

emlrtRSInfo emlrtRSI = { 24,           /* lineNo */
  "observationMatrix",                 /* fcnName */
  "/home/quentin/Desktop/MatlabCommented10092018/Benchmark/Identification/Utilities/observationMatrix.m"/* pathName */
};

emlrtRSInfo b_emlrtRSI = { 21,         /* lineNo */
  "regressor",                         /* fcnName */
  "/home/quentin/Desktop/MatlabCommented10092018/Benchmark/Identification/Utilities/regressor.m"/* pathName */
};

emlrtRSInfo c_emlrtRSI = { 28,         /* lineNo */
  "regressor",                         /* fcnName */
  "/home/quentin/Desktop/MatlabCommented10092018/Benchmark/Identification/Utilities/regressor.m"/* pathName */
};

emlrtRSInfo d_emlrtRSI = { 30,         /* lineNo */
  "regressor",                         /* fcnName */
  "/home/quentin/Desktop/MatlabCommented10092018/Benchmark/Identification/Utilities/regressor.m"/* pathName */
};

emlrtRSInfo e_emlrtRSI = { 49,         /* lineNo */
  "power",                             /* fcnName */
  "/opt/MATLAB/R2018a/toolbox/eml/lib/matlab/ops/power.m"/* pathName */
};

/* End of code generation (observationMatrix_data.c) */
