function y = measurement_RRR(x_km1)

y = x_km1(4:6);

end